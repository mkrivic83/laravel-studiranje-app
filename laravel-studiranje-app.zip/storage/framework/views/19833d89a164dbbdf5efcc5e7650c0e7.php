

<?php $__env->startSection('title', 'Novi student'); ?>
<?php $__env->startSection('page_title', 'Dodaj studenta'); ?>

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
  <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px;">
    <strong>Greške:</strong>
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($e); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<form class="form-box" method="POST" action="<?php echo e(route('studenti.store')); ?>">
  <?php echo csrf_field(); ?>

  <label>Ime</label>
  <input type="text" name="ime" value="<?php echo e(old('ime')); ?>">

  <label>Prezime</label>
  <input type="text" name="prezime" value="<?php echo e(old('prezime')); ?>">

  <label>Datum rođenja</label>
  <input type="date" name="datum_rod" value="<?php echo e(old('datum_rod')); ?>">

  <label>MBR</label>
  <input type="number" name="mbr" value="<?php echo e(old('mbr')); ?>">

  <label>Stipendija</label>
  <input type="number" step="0.01" name="stipendija" value="<?php echo e(old('stipendija', 0)); ?>">

  <label>Mjesto (može biti prazno)</label>
  <input type="text" name="mjesto" value="<?php echo e(old('mjesto')); ?>">

  <label>Fakultet</label>
  <select name="fakultetid" style="width: 80%; padding: 8px; margin-top: 5px;">
    <?php $__currentLoopData = $fakulteti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($f->id); ?>" <?php if(old('fakultetid') == $f->id): echo 'selected'; endif; ?>>
        <?php echo e($f->naziv); ?> (<?php echo e($f->mjesto); ?>)
      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>

  <button type="submit">Spremi</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\www\personal\LaravelOOP\laravel-studiranje-app\resources\views/studenti/create.blade.php ENDPATH**/ ?>