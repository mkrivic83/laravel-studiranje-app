

<?php $__env->startSection('title', 'Fakulteti'); ?>
<?php $__env->startSection('page_title', 'Popis fakulteta'); ?>

<?php $__env->startSection('content'); ?>

<table>
  <tr>
    <th>ID</th>
    <th>Naziv</th>
    <th>Mjesto</th>
  </tr>

  <?php $__currentLoopData = $fakulteti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($f->id); ?></td>
      <td><?php echo e($f->naziv); ?></td>
      <td><?php echo e($f->mjesto); ?></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\www\personal\LaravelOOP\laravel-studiranje-app\resources\views/fakulteti/index.blade.php ENDPATH**/ ?>