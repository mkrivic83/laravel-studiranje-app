

<?php $__env->startSection('title', 'Studenti'); ?>
<?php $__env->startSection('page_title', 'Popis studenata'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('uspjeh')): ?>
  <div class="uspjeh"><?php echo e(session('uspjeh')); ?></div>
<?php endif; ?>

<a class="btn" href="<?php echo e(route('studenti.create')); ?>">+ Novi student</a>

<table style="margin-top: 1rem;">
  <tr>
    <th>ID</th>
    <th>Ime</th>
    <th>Prezime</th>
    <th>Datum rođenja</th>
    <th>MBR</th>
    <th>Stipendija</th>
    <th>Mjesto</th>
    <th>Fakultet</th>
    <th>Akcije</th>
  </tr>

  <?php $__currentLoopData = $studenti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($s->id); ?></td>
      <td><?php echo e($s->ime); ?></td>
      <td><?php echo e($s->prezime); ?></td>
      <td><?php echo e($s->datum_rod->format('d.m.Y')); ?></td>
      <td><?php echo e($s->mbr); ?></td>
      <td><?php echo e(number_format($s->stipendija, 2, ',', '.')); ?></td>
      <td><?php echo e($s->mjesto); ?></td>
      <td><?php echo e($s->fakultet?->naziv); ?></td>
      <td>
        <a href="<?php echo e(route('studenti.show', $s)); ?>">Prikaži</a> |
        <a href="<?php echo e(route('studenti.edit', $s)); ?>">Uredi</a> |
        <form action="<?php echo e(route('studenti.destroy', $s)); ?>" method="POST" style="display:inline;">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button type="submit" onclick="return confirm('Obrisati?')">Obriši</button>
        </form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php if($totalPages > 1): ?>
<div class="pager">

  
  <?php if($page > 1): ?>
    <a href="?page=<?php echo e($page - 1); ?>">&lt;</a>
  <?php else: ?>
    <span class="disabled">&lt;</span>
  <?php endif; ?>

  
  <?php for($i = 1; $i <= $totalPages; $i++): ?>
    <?php if($i == $page): ?>
      <span class="active"><?php echo e($i); ?></span>
    <?php else: ?>
      <a href="?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
    <?php endif; ?>
  <?php endfor; ?>

  
  <?php if($page < $totalPages): ?>
    <a href="?page=<?php echo e($page + 1); ?>">&gt;</a>
  <?php else: ?>
    <span class="disabled">&gt;</span>
  <?php endif; ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\www\personal\LaravelOOP\laravel-studiranje-app\resources\views/studenti/index.blade.php ENDPATH**/ ?>