<!doctype html>
<html lang="hr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo $__env->yieldContent('title', 'Moja aplikacija'); ?></title>

  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

  <header class="site-header">
    <div class="container header-inner">
      <a class="logo" href="<?php echo e(url('/')); ?>">Moja Aplikacija</a>

      <nav class="nav">
        <a href="<?php echo e(url('/')); ?>" class="nav-link <?php echo e(request()->routeIs('home') ? 'active':''); ?>">Početna</a>
        <a href="<?php echo e(route('studenti.index')); ?>" class="nav-link <?php echo e(request()->routeIs('studenti.index') ? 'active':''); ?>">Studenti</a>
        <a href="<?php echo e(route('fakulteti.index')); ?>" class="nav-link <?php echo e(request()->routeIs('fakulteti.index') ? 'active':''); ?>">Fakulteti</a>
        <a href="<?php echo e(route('about.index')); ?>" class="nav-link <?php echo e(request()->routeIs('about.index') ? 'active':''); ?>">About</a>
      </nav>
    </div>
  </header>

  <main class="site-main">
    <div class="container">
      <h1 class="page-title"><?php echo $__env->yieldContent('page_title', 'Naslov stranice'); ?></h1>

      <div class="card">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </div>
  </main>

  <footer class="site-footer">
    <div class="container footer-inner">
      <span>© <?php echo e(date('Y')); ?> Vježba i ponavljanje</span>
      <span class="footer-muted">
        Okolina: <?php echo e(app()->environment()); ?> |
        DB: <?php echo e(config('database.connections.mysql.database')); ?>

      </span>
    </div>
  </footer>

</body>
</html><?php /**PATH C:\xampp\www\personal\LaravelOOP\laravel-studiranje-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>