

<?php $__env->startSection('title', 'Detalji studenta'); ?>
<?php $__env->startSection('page_title', 'Detalji studenta'); ?>

<?php $__env->startSection('content'); ?>

<p><strong>Ime:</strong> <?php echo e($student->ime); ?></p>
<p><strong>Prezime:</strong> <?php echo e($student->prezime); ?></p>
<p><strong>Datum rođenja:</strong> <?php echo e($student->datum_rod->format('d.m.Y')); ?></p>
<p><strong>MBR:</strong> <?php echo e($student->mbr); ?></p>
<p><strong>Stipendija:</strong> <?php echo e(number_format($student->stipendija, 2, ',', '.')); ?></p>
<p><strong>Mjesto:</strong> <?php echo e($student->mjesto); ?></p>
<p><strong>Fakultet:</strong> <?php echo e($student->fakultet?->naziv); ?> (<?php echo e($student->fakultet?->mjesto); ?>)</p>

<a class="btn" href="<?php echo e(route('studenti.index')); ?>">Natrag</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\www\personal\LaravelOOP\laravel-studiranje-app\resources\views/studenti/show.blade.php ENDPATH**/ ?>