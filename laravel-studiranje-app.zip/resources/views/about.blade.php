@extends('layouts.app')

@section('title', 'O projektu')
@section('page_title', 'O projektu')

@section('content')
  <p>Mini Laravel projekt: studenti i fakulteti (CRUD + middleware + testovi).</p>
@endsection